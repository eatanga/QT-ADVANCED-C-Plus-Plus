#ifndef SAVINGSACCOUNT_H
#define SAVINGSACCOUNT_H

class SavingsAccount {
private:
    double limit;
public:
    SavingsAccount(long accountId, double limit);
};

#endif // SAVINGSACCOUNT_H
